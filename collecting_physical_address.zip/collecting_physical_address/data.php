<!DOCTYPE html>
<html lang="en">
  <head>
    <title></title>
</head>
<body>
    <table border=1 cellspacing=0 cellpadding=10>
        <tr>
            <td>#</td>
            <td>Name</td>
            <td>Email</td>
            <td>Map</td>
            <td>Addrress</td>
            <td>State</td>
            <td>Country </td>
        </tr>

        <?php
require 'connection.php';
$rows=mysqli_query($conn,"SELECT * FROM tb_data ORDER BY id ESC");
$i=1;
foreach($rows as $row) :
?>
<tr>
        <td><?php echo $i++;?></td>
<td><?php echo $row["name"];?></td>
<td><?php echo $row["email"];?></td>
<td style="width:450px ; height:450px;"> <iframe src="https://www.google.com/maps/?q=<?php echo $row[latitude]; ?>,<?php echo $row[longitude];?>&hl=es;z=14&output=embed " style="width:100%; height:100%;"  frameborder="0"></iframe></td>
</tr>
<?php endforeach; ?>
    </table>
</body>
</html>