<?php 
require 'connection.php';

if(isset($POST["submit"]))
{
    $name=$_POST["name"];
    $email=$_POST["email"];
    $latitude=$_POST["latitude"];
    $longitude=$_POST["longitude"];
    $Address=$_POST["Address"];
    $State=$_POST["State"];
    $Country=$_POST["Country"];
    // $longitude=$_POST["longitude"];

    $query = "INSERT INTO tb_data VALUES ('','$name','$email','latitude','longitude','Address','State','Country')";
    mysqli_query($conn,$query);

    echo
    "
    <script>
        alert('Data Added Successfully');
        document.location.href = 'data.php';
    </script>
    ";
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
        <title>
        Insert Data
        </title>
    </head>
    <body onload="getLocation();">
<form class="myform" action="" method="post" autocomplete="off" >
        <label for="">Name</label>
        <input type="text" name="name" required value=""> <br>
        <label for="">Email</label>
        <input type="text"  name="email" required value=""> <br>
        <label for="">Address</label>
        <input type="text"  name="email" required value=""> <br>
        <label for="">State</label>
        <input type="text"  name="State" required value=""> <br>
        <label for="">Country</label>
        <input type="text"  name="Country" required value=""> <br>

        <input type="text" name="latitude" value=""> <br>
        
        <input type="text" name="longitude" value=""> <br>
        <button type="submit" name="submit">Submit</button>
</form>
<script type="text/javascript">
    function getLocation(){
        if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition,showError);
        }
    }
    function showPosition(position){
        document.querySelector('.myForm input[name = "latitude"]').value=position.coords.latitude;
        document.querySelector('.myForm input[name = "longitude"]').value=position.coords.longitude;
        
        // document.querySelector('.myForm input[name = "latitude"]').value = position.coords.latitude;
        // document.querySe1ector('.myForm input[name = "longitude"]').value = position.coords.longitude;
    }
    function showError(error)
    {
        switch(error.code){
            case error.PERMISSION_DENIED:
                alert("You must allow the request for geolocation permission!")
                location.reload();
                break;

        }
    }
</script>

<a href="data.php">Database</a>
    </body>
</html>
