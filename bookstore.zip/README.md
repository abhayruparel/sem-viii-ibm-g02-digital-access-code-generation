# online-book-store-project-in-php

more details and demo http://projectworlds.in/online-book-store-project-in-php/


Doc file.
https://docs.google.com/document/d/1ycnz4--ukx8F7IrZR7eqNDAcPn9hC2LPjgPcyspKLEM/edit?usp=sharing

#for sql injection and cross site scrpiting 
https://geekflare.com/static-site-security-tips/ 

#for aes encryption and decryption
https://www.phpcluster.com/aes-encryption-and-decryption-in-php/
