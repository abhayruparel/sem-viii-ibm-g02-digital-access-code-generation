<?php

// Redirect browser
header("Location: page/index.php");

exit;
?>
