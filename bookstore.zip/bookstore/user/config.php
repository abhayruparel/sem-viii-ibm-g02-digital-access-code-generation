<?php

$conn = mysqli_connect("localhost", "root", "", "bookstore");

if (!$conn) {
    echo "Connection Failed";
}